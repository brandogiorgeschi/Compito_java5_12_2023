import java.io.*;
public class Main {
    public static void main(String[] Args) {
        Point circle1 = new Point();
        Point circle2 = new Point();
        Point circle3 = new Point();
        Point circle4 = new Point();


        BufferedReader keyboard = new BufferedReader(new InputStreamReader(System.in));

        int x;
        int y;
        for (int i = 0; i <= 4; i++) {//scelta progettuale dimensione di 4 essendo 4 le variabili associate alla classe Circle

            System.out.println("Inserire la cordinata X della circonferenza");
            try {
                x = Integer.parseInt(keyboard.readLine());
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println("Inserire la cordinata Y della circonferenza");
            try {
                y = Integer.parseInt(keyboard.readLine());

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            if (i == 1) {
                circle1=new Point(x,y);
            }
            if (i == 2) {
                circle2=new Point(x,y);
            }
            if (i == 3) {
                circle3=new Point(x,y);
            }
            if (i == 4) {
                circle4=new Point(x,y);
            }
        }
    }
}