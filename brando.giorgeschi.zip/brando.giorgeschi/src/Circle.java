public class Circle {
    private Point point; //si usa int al posto di double perché per scelta progettuale nel piano cartesiano si usano solo interi e non valori con virgola
    private double raggio;

    public Circle(Point point, double raggio) {
            this.point = point;
            this.raggio = raggio;

    }
    public Point getPoint() {
        return point;
    }

    public double getRaggio() {
        return raggio;
    }


}





